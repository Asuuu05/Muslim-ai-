# Muslim AI — Android Studio starter

This is a starter Android app for Samsung/Android with a voice UI and a basic **“Hey Muslim”** phrase check.

## What it currently does
- Requests microphone permission.
- Uses Android speech recognition while the app is open and listening.
- Detects “Hey Muslim” in recognized speech.
- Responds using Android Text-to-Speech.
- Supports basic time/date, YouTube, WhatsApp, and browser commands.

## Important limitation
This is **not yet an always-on, screen-locked wake-word assistant**. Android's general speech recognizer is not a dedicated wake-word engine and may pause/restart. Background/locked-screen wake-word support needs a dedicated on-device wake-word engine, a trained custom model for “Hey Muslim”, and a microphone foreground service with a persistent notification. This starter does not include those pieces or a cloud AI API.

## Open in Android Studio
1. Extract the ZIP.
2. Open the `MuslimAI_AndroidStudio` folder in Android Studio.
3. Allow Gradle sync to finish (Android Studio may download Android Gradle Plugin dependencies).
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press **Run** and allow microphone permission.
6. Tap **Start Listening**, then say “Hey Muslim, what time is it?”

## Build APK
In Android Studio, choose **Build > Build APK(s)**. The debug APK is usually placed under `app/build/outputs/apk/debug/` after a successful build.

## Privacy
Speech recognition may be provided by the speech service configured on your phone and may send audio to that provider. Do not use this starter for sensitive conversations without reviewing your device's speech-recognition privacy settings.
