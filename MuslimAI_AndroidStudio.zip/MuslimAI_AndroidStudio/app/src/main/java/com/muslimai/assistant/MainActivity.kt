package com.muslimai.assistant

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var statusText: TextView
    private lateinit var heardText: TextView
    private lateinit var toggleButton: Button
    private val handler = Handler(Looper.getMainLooper())
    private var listening = false
    private var waitingForCommand = false
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "Speech recognition is not available on this phone."
            toggleButton.isEnabled = false
        }
        requestAudioPermission()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(0xFFF4F7F5.toInt())
        }
        val title = TextView(this).apply {
            text = "Muslim AI"
            textSize = 30f
            setTextColor(0xFF123B30.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your voice assistant"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 30)
        }
        statusText = TextView(this).apply {
            text = "Ready. Tap Start, then say “Hey Muslim”."
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(8, 20, 8, 20)
        }
        heardText = TextView(this).apply {
            text = "Heard: —"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(8, 8, 8, 24)
        }
        toggleButton = Button(this).apply {
            text = "Start Listening"
            setOnClickListener {
                if (listening) stopListening() else startListening()
            }
        }
        val hint = TextView(this).apply {
            text = "Try: “Hey Muslim, what time is it?” or “Hey Muslim, open YouTube.”\n\nKeep this app open for wake-word detection."
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(8, 28, 8, 8)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(statusText)
        root.addView(heardText)
        root.addView(toggleButton)
        root.addView(hint)
        setContentView(root)
    }

    private fun requestAudioPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 20)
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestAudioPermission()
            statusText.text = "Please allow microphone permission, then tap Start."
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            statusText.text = "Speech recognition is unavailable."
            return
        }
        listening = true
        waitingForCommand = false
        toggleButton.text = "Stop Listening"
        statusText.text = "Listening for “Hey Muslim”…"
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
        beginRecognition()
    }

    private fun beginRecognition() {
        if (!listening) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleRestart(900)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (listening) statusText.text = if (waitingForCommand) "Hey Muslim detected — say a command…" else "Listening for “Hey Muslim”…"
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {
            if (listening) scheduleRestart(700)
        }
        override fun onResults(results: Bundle?) {
            if (!listening) return
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val spoken = matches?.firstOrNull().orEmpty().lowercase(Locale.ROOT).trim()
            if (spoken.isNotBlank()) {
                heardText.text = "Heard: $spoken"
                handleSpeech(spoken)
            } else {
                scheduleRestart(500)
            }
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleSpeech(spoken: String) {
        val wakePhrases = listOf("hey muslim", "hey, muslim", "hi muslim", "hey muslin")
        val phrase = wakePhrases.firstOrNull { spoken.contains(it) }

        if (phrase != null) {
            val command = spoken.substringAfter(phrase).trim().trim(',', '.', '!', '?')
            if (command.isNotBlank()) {
                waitingForCommand = false
                runCommand(command)
            } else {
                waitingForCommand = true
                statusText.text = "Hey Muslim detected — say a command…"
                speak("Ji, main sun raha hoon. Bataiye, kya karna hai?")
            }
        } else if (waitingForCommand) {
            waitingForCommand = false
            runCommand(spoken)
        } else {
            statusText.text = "Wake phrase not detected. Say “Hey Muslim”."
        }
        scheduleRestart(700)
    }

    private fun runCommand(command: String) {
        val c = command.lowercase(Locale.ROOT)
        when {
            c.contains("time") || c.contains("waqt") || c.contains("what time") -> {
                val time = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
                statusText.text = "It is $time"
                speak("The time is $time")
            }
            c.contains("date") || c.contains("today") || c.contains("tareekh") -> {
                val date = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
                statusText.text = "Today is $date"
                speak("Today is $date")
            }
            c.contains("youtube") -> openAppOrWeb("com.google.android.youtube", "https://www.youtube.com", "Opening YouTube.")
            c.contains("whatsapp") -> openAppOrWeb("com.whatsapp", "https://www.whatsapp.com", "Opening WhatsApp.")
            c.contains("chrome") || c.contains("browser") || c.contains("internet") -> {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
                    statusText.text = "Opening browser."
                    speak("Opening browser.")
                } catch (_: Exception) { speak("I could not open the browser.") }
            }
            c.contains("stop listening") || c == "stop" -> stopListening()
            else -> {
                statusText.text = "I heard: $command"
                speak("I heard $command. More AI features can be added to this starter app.")
            }
        }
    }

    private fun openAppOrWeb(packageName: String, url: String, response: String) {
        try {
            val launch = packageManager.getLaunchIntentForPackage(packageName)
            if (launch != null) startActivity(launch)
            else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            statusText.text = response
            speak(response)
        } catch (_: ActivityNotFoundException) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
            speak(response)
        } catch (_: Exception) {
            speak("Sorry, I could not open that app.")
        }
    }

    private fun speak(message: String) {
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "muslim-ai-utterance")
    }

    private fun scheduleRestart(delay: Long) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (listening) beginRecognition()
        }, delay)
    }

    private fun stopListening() {
        listening = false
        waitingForCommand = false
        handler.removeCallbacksAndMessages(null)
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        speechRecognizer?.destroy()
        speechRecognizer = null
        toggleButton.text = "Start Listening"
        statusText.text = "Stopped. Tap Start to listen again."
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale.getDefault()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            statusText.text = "Microphone permission granted. Tap Start Listening."
        } else if (requestCode == 20) {
            statusText.text = "Microphone permission is required."
        }
    }

    override fun onDestroy() {
        listening = false
        handler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
